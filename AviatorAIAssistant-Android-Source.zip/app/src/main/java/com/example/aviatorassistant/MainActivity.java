package com.example.aviatorassistant;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root, resultsBox;
    private EditText multiplierInput;
    private TextView summary;
    private final ArrayList<Double> results = new ArrayList<>();
    private static final String PREFS = "rounds";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        results.clear();
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString("values", "");
        if (!saved.isEmpty()) {
            for (String s : saved.split(",")) try { results.add(Double.parseDouble(s)); } catch (Exception ignored) {}
        }
        buildUI();
        refreshStats();
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 28, 22, 24); root.setBackgroundColor(Color.rgb(16,22,34));
        scroll.addView(root); setContentView(scroll);

        TextView title = text("AVIATOR AI ASSISTANT", 23, Color.WHITE);
        root.addView(title);
        TextView sub = text("Floating tracker • Android starter build", 14, Color.LTGRAY);
        root.addView(sub);

        TextView disclaimer = text("This app tracks observed results. Historical data cannot reliably reveal the next random multiplier; estimates are not betting advice.", 14, Color.rgb(255,210,130));
        disclaimer.setPadding(0,18,0,18); root.addView(disclaimer);

        Button overlayPermission = button("1. Enable floating assistant");
        overlayPermission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else Toast.makeText(this, "Overlay permission is already enabled.", Toast.LENGTH_SHORT).show();
        });
        root.addView(overlayPermission);

        Button startOverlay = button("2. Start floating assistant");
        startOverlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Enable floating permission first.", Toast.LENGTH_LONG).show();
                return;
            }
            startService(new Intent(this, FloatingService.class));
            Toast.makeText(this, "Floating assistant started. Return to the game; tap ✕ to close it.", Toast.LENGTH_LONG).show();
        });
        root.addView(startOverlay);

        root.addView(text("Record a multiplier", 19, Color.WHITE));
        multiplierInput = new EditText(this);
        multiplierInput.setSingleLine(true);
        multiplierInput.setHint("Example: 2.45");
        multiplierInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        multiplierInput.setTextColor(Color.WHITE); multiplierInput.setHintTextColor(Color.GRAY);
        root.addView(multiplierInput);

        Button add = button("Add result");
        add.setOnClickListener(v -> addResult());
        root.addView(add);

        Button undo = button("Undo last result");
        undo.setOnClickListener(v -> {
            if (!results.isEmpty()) { results.remove(results.size()-1); save(); refreshStats(); }
        });
        root.addView(undo);

        summary = text("", 16, Color.WHITE); summary.setPadding(0,20,0,12); root.addView(summary);
        root.addView(text("Recent results (newest first)", 18, Color.WHITE));
        resultsBox = new LinearLayout(this); resultsBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(resultsBox);

        Button clear = button("Clear all history");
        clear.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
            .setTitle("Clear history?").setMessage("This permanently clears locally saved results.")
            .setNegativeButton("Cancel", null).setPositiveButton("Clear", (d,w) -> { results.clear(); save(); refreshStats(); }).show());
        root.addView(clear);
    }

    private void addResult() {
        String s = multiplierInput.getText().toString().trim().replace(',', '.');
        try {
            double x = Double.parseDouble(s);
            if (!Double.isFinite(x) || x < 1.0 || x > 1000000) throw new NumberFormatException();
            results.add(x); save(); multiplierInput.setText(""); refreshStats();
        } catch (Exception e) {
            Toast.makeText(this, "Enter a valid multiplier, e.g. 1.75", Toast.LENGTH_SHORT).show();
        }
    }

    private void save() {
        StringBuilder b = new StringBuilder();
        for (double x : results) { if (b.length() > 0) b.append(","); b.append(x); }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("values", b.toString()).apply();
    }

    private String range(double x) {
        if (x < 1.5) return "1.00–1.49x";
        if (x < 2.0) return "1.50–1.99x";
        if (x < 5.0) return "2.00–4.99x";
        return "5.00x+";
    }

    private void refreshStats() {
        if (summary == null) return;
        int n = results.size();
        int[] counts = new int[4];
        for (double x : results) {
            if (x < 1.5) counts[0]++; else if (x < 2) counts[1]++; else if (x < 5) counts[2]++; else counts[3]++;
        }
        int best = 0;
        for (int i=1;i<4;i++) if (counts[i] > counts[best]) best=i;
        String[] names = {"1.00–1.49x", "1.50–1.99x", "2.00–4.99x", "5.00x+"};
        StringBuilder s = new StringBuilder("Rounds recorded: ").append(n).append("\n\nHistorical frequency:");
        for (int i=0;i<4;i++) s.append(String.format(Locale.US, "\n• %s: %d (%.1f%%)", names[i], counts[i], n == 0 ? 0 : counts[i]*100.0/n));
        s.append("\n\nBaseline estimate: ").append(n == 0 ? "Collect results first" : names[best]);
        s.append("\nThis is only the most frequent past category—not a reliable prediction.");
        summary.setText(s.toString());

        resultsBox.removeAllViews();
        int shown=0;
        for (int i=n-1;i>=0 && shown<50;i--,shown++) {
            TextView row = text(String.format(Locale.US, "%d. %.2fx  •  %s", n-i, results.get(i), range(results.get(i))), 15, Color.WHITE);
            row.setPadding(8,9,8,9); row.setBackgroundColor(shown%2==0?Color.rgb(27,36,52):Color.rgb(20,28,42));
            resultsBox.addView(row);
        }
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0,8,0,8); b.setLayoutParams(p); return b;
    }
}
