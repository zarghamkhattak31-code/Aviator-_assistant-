package com.example.aviatorassistant;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14,10,14,10);
        box.setBackgroundColor(Color.rgb(20,30,48));

        TextView title = new TextView(this);
        title.setText("✈ Aviator Assistant");
        title.setTextColor(Color.WHITE); title.setTextSize(16);
        box.addView(title);

        TextView body = new TextView(this);
        body.setText("Floating tracker active\nAdd results in the main app.\nNo reliable next-round prediction.");
        body.setTextColor(Color.rgb(220,230,245)); body.setTextSize(12);
        body.setPadding(0,8,0,8); box.addView(body);

        Button open = new Button(this); open.setText("Open tracker"); open.setAllCaps(false);
        open.setOnClickListener(v -> {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        });
        box.addView(open);

        Button close = new Button(this); close.setText("✕ Hide assistant"); close.setAllCaps(false);
        close.setOnClickListener(v -> stopSelf()); box.addView(close);

        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 18; params.y = 220;
        box.setOnTouchListener(new View.OnTouchListener() {
            private int sx, sy, wx, wy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx=(int)e.getRawX(); sy=(int)e.getRawY(); wx=params.x; wy=params.y; return false;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x=wx + sx-(int)e.getRawX(); params.y=wy+(int)e.getRawY()-sy;
                    try { wm.updateViewLayout(box, params); } catch(Exception ignored) {}
                    return false;
                }
                return false;
            }
        });
        panel = box;
        try { wm.addView(panel, params); } catch(Exception e) { stopSelf(); }
    }

    @Override public void onDestroy() {
        if (wm != null && panel != null) try { wm.removeView(panel); } catch(Exception ignored) {}
        super.onDestroy();
    }
}
