# Aviator AI Assistant (Android starter project)

This is a starter Android project for a floating, on-screen Aviator results tracker.

## What it does
- Android app with a dashboard to enter observed multiplier results.
- Stores recent results locally while the app is installed.
- Shows descriptive historical statistics and a simple baseline range estimate.
- Requests Android's "display over other apps" permission and starts a floating overlay panel.
- Overlay includes Start/Hide controls and a quick link back to the dashboard.

## Important limitations
- This is source code, not a compiled APK.
- It does NOT connect to P88 or Spribe servers, bypass protections, or automatically read the game's screen yet.
- It does NOT reliably predict future multipliers. The displayed estimate is a historical-frequency baseline, not a signal with proven predictive power.
- Screen reading with Android MediaProjection/OCR is a separate feature that requires explicit permission and careful device testing.

## Build on an Android phone
1. Extract this ZIP.
2. Open the project folder in an Android-compatible IDE/build environment that supports Gradle and Android SDK.
3. Build the `app` module into a debug APK.
4. Install the APK and open it.
5. Tap **Enable floating assistant** and grant the Android overlay permission.
6. Tap **Start floating assistant**.

This project uses Android Gradle Plugin 8.6.1 and Gradle 8.7. A compatible Java 17 and Android SDK installation are required.

## Safety
The assistant is for observing and analyzing publicly visible results. Do not provide account passwords, OTPs, or payment information. Never rely on its estimates for gambling decisions.
